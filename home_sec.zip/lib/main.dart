import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:iamrich/UI/CustomInputField.dart';
import 'UI/ForgotPassword.dart';
import 'UI/HomePage.dart';
import 'UI/routes.dart';

void main() => runApp(MaterialApp(
  title: 'Login Page',
    home: Login()
));//MaterialApp


class Login extends StatelessWidget{


@override
  Widget build(BuildContext context) {
  // TODO: implement build
  return new MaterialApp(
    routes: routes,
    );}
  }
