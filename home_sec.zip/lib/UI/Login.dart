import 'dart:ui';
import 'package:flutter/material.dart';

import 'CustomInputField.dart';
import 'ForgotPassword.dart';
import 'HomePage.dart';

class Login extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return LoginState();
  }

}

class LoginState extends State<Login>{

  final formKey = GlobalKey<FormState>();

  Map data ={'username':String,'password':int};
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Container(
        width: MediaQuery
            .of(context)
            .size
            .width,
        height: MediaQuery
            .of(context)
            .size
            .height,
        color: Colors.cyan,

        child: Stack(
          children:<Widget>[
            Align(
              alignment: Alignment.bottomRight,
              widthFactor: 0.5,
              heightFactor: 0.5,
              child:Material(
                color:Color.fromRGBO(255,255,255,0.4),
                borderRadius: BorderRadius.all(Radius.circular(200)),
                child: Container(
                  width: 400,
                  height: 400,
                  ),
                ),),
            Align(
              alignment: Alignment.bottomLeft,
              widthFactor: 0.2,
              heightFactor: 0.2,
              child:Material(
                color:Color.fromRGBO(255,255,255,0.4),
                borderRadius: BorderRadius.all(Radius.circular(300)),
                child: Container(
                  width: 400,
                  height: 400,
                  ),
                ),),
            Center(
              child: Container(
                width: 400,
                height: 400,
                child:Form(
                  key: formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget>[
                    Material(
                        elevation:10.0,
                        borderRadius: BorderRadius.all(Radius.circular(100.0)),
                        child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Image.asset('images/homesec.png',width:100,height:100))),
                    CustomInputField(
                        Icon(Icons.person,color:Colors.white),'Username'),
                    CustomInputField(
                        Icon(Icons.lock,color:Colors.white),'Password'),
                    SizedBox(height:5.0),
                    Container(
                      width:150,
                      height: 60,
                      child: RaisedButton(onPressed: (){
                        Navigator.push(
                          context, MaterialPageRoute(builder: (context) => HomePage()),
                          );
                      },color:Colors.cyanAccent,textColor:Colors.white,
                                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(10.0))),
                                            child:Text('Login',style: TextStyle(
                                                fontSize: 20
                                                ),),

                                          ),),
                    SizedBox(height:5.0),
                    ForgotPassword(),],
                  )),
                ),
              ),
          ],
          ),

        ),
      );

  }
}