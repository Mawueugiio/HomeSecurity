import 'package:flutter/material.dart';
import 'Login.dart';
import 'HomePage.dart';
import 'HelpDesk.dart';
import 'MonitoringPage.dart';
import 'Records.dart';

final routes = {
  '/login':         (BuildContext context) => new Login(),
  '/home':         (BuildContext context) => new HomePage(),
  '/monitor' :       (BuildContext context) => new MonitoringPage(),
  '/help' :       (BuildContext context) => new HelpDesk(),
  '/' :          (BuildContext context) => new Login(),
};

