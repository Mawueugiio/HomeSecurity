import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';


class Records extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Records'),
        ),
      body: Center(
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text('Name: '),
              Text('Date '),
              Text('Time of Arrival'),
              Text('Time of Departure'),
            ]),
        ),
      );


  }
}
