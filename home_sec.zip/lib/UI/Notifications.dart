import 'package:flutter/material.dart';

class Notifications extends StatelessWidget{


  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return MaterialApp(
      title: 'Monitoring Page',
      theme: ThemeData(
        primarySwatch: Colors.cyan,

        ),
      home: MyNotification(title: 'Notification'),
      );
  }
}

class MyNotification extends StatefulWidget{
  MyNotification({Key key, this.title}) : super(key: key);
  final String title;

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return null;
  }
}